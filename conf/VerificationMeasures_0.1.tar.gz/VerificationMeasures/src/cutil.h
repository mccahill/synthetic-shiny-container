void L1partition(int* hist, int n1, int* x, int n, double epsilon,  double ratio, long seed);
void L1partition_approx(int* hist, int n1, int* x, int n, double epsilon,  double ratio, long seed);

